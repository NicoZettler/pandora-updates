"""
Software collection 2023 - originated from PCAPS,
developed for OnPoRob in 2020 by Garcia and Bielke.
Extended by multiple students at the ZOT.
Author: Luis Garcia
Facility: ZOT
University: Aalen University
"""
import sys
import os

from threading import Thread
from queue import Queue

# own module imports
from pandora.GLOBALS import PLATFORM
from pandora.GUI.MainWindow import MainWindow
from pandora.FDM_printing.printing_fdm import FDMPrinting
from pandora.IPC import IPC
from pandora.GUI.pyqtImport import *

if hasattr(QtCore.Qt, 'AA_EnableHighDpiScaling'):
    QtWidgets.QApplication.setAttribute(QtCore.Qt.AA_EnableHighDpiScaling, True)

if hasattr(QtCore.Qt, 'AA_UseHighDpiPixmaps'):
    QtWidgets.QApplication.setAttribute(QtCore.Qt.AA_UseHighDpiPixmaps, True)

print(PLATFORM)

"""
Important note:
Right click on "pandora/src" folder --> Mark directory as --> source
Right click on "pandora/build" folder --> Mark directory as --> excluded
"""


class Pandora(QGraphicsObject, IPC):
    # indicator if maps routine stopped
    maps_stopped = True

    # queue to put the created raw path into
    q_path = Queue()

    def __init__(self, app):
        super(Pandora, self).__init__()

        self.main_window = MainWindow(self.e_thread_kill, app)

        # create object instances of the modules
        # self.analyze = PathAnalyze(self.main_window)
        # self.sim_contr = ControllerSimulation(self.main_window, self.s_stop_MAPS)
        self.fdm_printing = FDMPrinting(self.main_window)

        self.button_clicked_listener()
        self.threading()

    def button_clicked_listener(self):
        """
        Function calls for when a button is pressed.
        """
        # milling
        if self.main_window.tool_ctrl is not None:
            self.main_window.tool_ctrl.btnSpindelStart.clicked.connect(self.milling.milling_head.start_milling_spindle)
            self.main_window.tool_ctrl.btnSpindelStop.clicked.connect(self.milling.milling_head.stop_milling_spindle)

        # 3D/6D printing
        if self.main_window.robot_printing is not None:
            # self.main_window.robot_printing.btnStopRobot.clicked.connect(stop_robot)
            self.main_window.robot_printing.btnPlotPrintModel.clicked.connect(self.fdm_printing.plot_printing_model)
            self.main_window.robot_printing.btnClear3DPrintPreview.clicked.connect(
                self.main_window.robot_printing.wPrintingPreview.clear_path)
            self.main_window.robot_printing.btnPrintModel.clicked.connect(self.create_printing_path)
            self.main_window.robot_printing.btnSprayModel.clicked.connect(self.create_path_from_zaphod)
            # serial connection
            self.main_window.robot_printing.btnconnectTemp.clicked.connect(self.fdm_printing.connect_serial_temp)
            self.main_window.robot_printing.btnconnectExtr.clicked.connect(self.fdm_printing.connect_serial_extr)
            self.main_window.robot_printing.btnconnectCross.clicked.connect(self.fdm_printing.connect_serial_cross)
            # temperature settings
            self.main_window.robot_printing.dial_temperature_Printbed.sliderReleased.connect(
                self.fdm_printing.send_temperature_printbed)
            self.main_window.robot_printing.dial_temperature_Printhead_1.sliderReleased.connect(
                self.fdm_printing.send_temperature_printhead_1)
            self.main_window.robot_printing.dial_temperature_Printhead_2.sliderReleased.connect(
                self.fdm_printing.send_temperature_printhead_2)
            self.main_window.robot_printing.btnStartStopClimaControllPrintbed.clicked.connect(
                self.fdm_printing.start_stop_pid_printbed)
            self.main_window.robot_printing.btnStartStopClimaControllPrinthead_1.clicked.connect(
                self.fdm_printing.start_stop_pid_printhead_1)
            self.main_window.robot_printing.btnStartStopClimaControllPrinthead_2.clicked.connect(
                self.fdm_printing.start_stop_pid_printhead_2)
            # extruder settings
            self.main_window.robot_printing.btnHomeExtruder.clicked.connect(self.fdm_printing.home_extruder)
            self.main_window.robot_printing.btnSetExtruderZeroValue.clicked.connect(
                self.fdm_printing.set_extruder_to_zero)
            self.main_window.robot_printing.btnExtruderUp.clicked.connect(self.fdm_printing.drive_extruder_up)
            self.main_window.robot_printing.btnExtruderDown.clicked.connect(self.fdm_printing.drive_extruder_down)
            self.main_window.robot_printing.rbAbsolutPositionMode.clicked.connect(
                lambda: self.fdm_printing.radiobutton_toggled_extruder_drive_mode('absolut'))
            self.main_window.robot_printing.rbRelativePositionMode.clicked.connect(
                lambda: self.fdm_printing.radiobutton_toggled_extruder_drive_mode('relative'))
            self.main_window.robot_printing.btnSetExtruderSpeedfactor.clicked.connect(
                self.fdm_printing.set_extruder_speed_factor)
            self.main_window.robot_printing.btnSetExtruderFeedrate.clicked.connect(
                self.fdm_printing.set_extruder_feedrate)
            self.main_window.robot_printing.btnExtrFeedrateplus.clicked.connect(self.fdm_printing.feedrate_inkrement)
            self.main_window.robot_printing.btnExtrFeedrateminus.clicked.connect(self.fdm_printing.feedrate_dekrement)
            self.main_window.robot_printing.btnSetExtruderTimeOffset.clicked.connect(
                self.fdm_printing.set_extruder_time_offset)

    def threading(self):
        # Threads
        """
        Desc.: Bioprint serial read extruder incoming communication
        In: s_serialCOM_extr
        Out: -
        """
        self.t_serial_read_extruder = Thread(target=self.fdm_printing.read_serial_extr, args=(self.e_thread_kill,))
        # self.t_serial_read_extruder.start()

        """
        Desc.: Bioprint serial data for the Extruder with timedelay
        """
        self.t_gcode_for_extruder = Thread(target=self.fdm_printing.drive_extruder_by_gcode, args=(self.e_thread_kill,))
        # self.t_gcode_for_extruder.start()
        """
        Desc.: Bioprint serial read temperature controller incoming communication
        In: s_serialCOM_temp
        Out: -
        """
        self.t_serialread_temp = Thread(target=self.fdm_printing.read_serial_temp, args=(self.e_thread_kill,))
        # self.t_serialread_temp.start()


def main():
    # Create QApplication and start the main application
    app = QApplication(sys.argv)
    pandora = Pandora(app)
    sys.exit(app.exec())

if __name__ == "__main__":
    main()