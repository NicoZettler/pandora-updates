import math

import cv2
import numpy as np
import pandas as pd
from skimage import filters
from scipy import optimize


class Scalar:
    def __init__(self, x=None, y=None, z=None, alpha=None, beta=None, theta=None):
        self.x = x
        self.y = y
        self.z = z
        self.alpha = alpha
        self.beta = beta
        self.theta = theta
        self.length = 0.0
        self.magnitude()

    def __add__(self, other):
        if type(other) == np.float64 or type(other) == float:
            x = self.x + other
            y = self.y + other
            z = self.z + other

        elif type(other) == Scalar:
            x = self.x + other.x
            y = self.y + other.y
            z = self.z + other.z
        else:
            print("No valid data type for addition with Scalar datatype")
            return None

        return Scalar(x, y, z)

    def __sub__(self, other):
        if type(other) == np.float64 or type(other) == float:
            x = self.x - other
            y = self.y - other
            z = self.z - other
        elif type(other) == Scalar:
            x = self.x - other.x
            y = self.y - other.y
            z = self.z - other.z
        else:
            print("No valid data type for substraction with Scalar datatype")
            return None

        return Scalar(x, y, z)

    def __mul__(self, other):
        if type(other) == np.float64 or type(other) == float:
            x = self.x * other
            y = self.y * other
            z = self.z * other
        elif type(other) == Scalar:
            x = self.x * other.x
            y = self.y * other.y
            z = self.z * other.z
        else:
            print("No valid data type for multiplication with Scalar datatype")
            return None

        return Scalar(x, y, z)

    def __truediv__(self, other):
        if other == 0.0 or other == 0:
            x = np.nan
            y = np.nan
            z = np.nan
        elif type(other) == np.float64 or type(other) == float:
            x = self.x / other
            y = self.y / other
            z = self.z / other
        elif type(other) == Scalar:
            x = self.x / other.x
            y = self.y / other.y
            z = self.z / other.z
        else:
            print("No valid data type for multiplication with Scalar datatype")
            return None

        return Scalar(x, y, z)

    def __pow__(self, other):
        if type(other) == np.float64 or type(other) == float:
            x = self.x ** other
            y = self.y ** other
            z = self.z ** other
        elif type(other) == Scalar:
            x = self.x ** other.x
            y = self.y ** other.y
            z = self.z ** other.z
        else:
            print("No valid data type for multiplication with Scalar datatype")
            return None

        return Scalar(x, y, z)

    def __eq__(self, other):
        if other is Scalar:
            if self.x == other.x and self.y == other.y and self.z == other.z:
                return True
            else:
                return False
        else:
            print("The == operation is only defined for datatype: Scalar == Scalar")

    def __ne__(self, other):
        if other is Scalar:
            if self.x == other.x and self.y == other.y and self.z == other.z:
                return False
            else:
                return True
        else:
            print("The != operation is only defined for datatype: Scalar != Scalar")

    def dot(self, other):
        """
        Calculates the dot product of two given vectors

        returns: np.float64
        """
        product = self.x * other.x + self.y * other.y + self.z * other.z
        return product

    def rotate(self, axis: str, angle: float):
        """
        This function rotates the scalar around a given axis by a given angle.
        """
        # Transformation of the scalar values into a homogenous coordinate system
        array = np.array([self.x, self.y, self.z, 1])

        # Rotation around x-axis
        if axis == "x" or axis == "X":
            # Definition of the rotation matrix 
            rotation_matrix = np.array([[1, 0, 0, 0]
                                           , [0, np.cos(angle), np.sin(-angle), 0]
                                           , [0, -np.sin(-angle), np.cos(angle), 0]
                                           , [0, 0, 0, 1]])

        # Rotation around y-axis
        elif axis == "y" or axis == "Y":
            rotation_matrix = np.array([[np.cos(angle), 0, -np.sin(-angle), 0]
                                           , [0, 1, 0, 0]
                                           , [np.sin(-angle), 0, np.cos(angle), 0]
                                           , [0, 0, 0, 1]])

        # Rotation around y.axis
        elif axis == "z" or axis == "Z":
            rotation_matrix = np.array([[np.cos(angle), np.sin(-angle), 0, 0]
                                           , [-np.sin(-angle), np.cos(angle), 0, 0]
                                           , [0, 0, 1, 0]
                                           , [0, 0, 0, 1]])

        # Error handling for wrong input
        else:
            print("No valid axis has been choosen: Valid Axis are: x,y,z or X,Y,Z")
            return None

        # Set the new coords of the scalar
        self.x, self.y, self.z, _ = (array * rotation_matrix).sum(axis=1)

    def get_ndarray_with_coords(self):
        return np.array([self.x, self.y, self.z])

    def magnitude(self) -> float:
        if self.x is not None and self.y is not None and self.z is not None:
            self.length = np.linalg.norm(np.array([self.x, self.y, self.z]))
            return self.length


class Vector:
    def __init__(self, p1=Scalar(0, 0, 0), p2=Scalar(0, 0, 0)):

        self.start = p1
        self.direction = p2 - self.start
        self.ndirection = None
        self.length = 0.0
        self.normalize()

    def __mul__(self, other):
        if type(other) is float or type(other) is np.float64:
            self.direction = Vector(p2=self.direction * other)
        else:
            print("This function multiplies a vector with a scalar and the wrong scalar datatype is given!")

    def normalize(self):
        """
        Vector normalization
        """
        self.get_length()
        self.ndirection = self.direction / self.length

    def get_length(self):
        """
        Calculates the length of a given vector
        """
        self.length = np.sqrt(self.direction.x * self.direction.x + self.direction.y * self.direction.y
                              + self.direction.z * self.direction.z)

    def cross(self, other):
        """
        Calculates the crossproduct /vectorproduct between the vector and anOTHER vector that is given to the function

        returns: Vektor
        """
        n1 = self.direction.y * other.direction.z - self.direction.z * other.direction.y
        n2 = self.direction.z * other.direction.x - self.direction.x * other.direction.z
        n3 = self.direction.x * other.direction.y - self.direction.y * other.direction.x
        normal_v = Vector(p2=Scalar(n1, n2, n3))
        return normal_v

    def dot(self, other):
        """
        Calculates the dot product of two given vectors

        returns: np.float64
        """
        product = self.direction.x * other.direction.x + self.direction.y * other.direction.y \
                  + self.direction.z * other.direction.z
        return product


class Plane:
    """
    A plane in 3D coordinate space is determined by a point and a vector that is perpendicular to the plane.
    https://brilliant.org/wiki/3d-coordinate-geometry-equation-of-a-plane/#:~:text=A%20plane%20in%203D%20coordinate,plane%20from%20different%20given%20perspectives.

    The vector that is normal to the plane is calculated by the two positional vectors v1 and v2. Both vectors start
    in the position of LED0 and end either in LED1 or LED2.
    """

    def __init__(self, origin: Scalar, v1: Vector, v2: Vector):
        self.origin = origin
        self.norm_vector = v1.cross(v2)

    def get_intersection(self, v1):
        denominator = v1.dot(self.norm_vector)
        if denominator != 0:
            nominator = (Vector(p2=(self.origin - v1.start))).dot(self.norm_vector)
            d = nominator / denominator
            point = v1.start + (v1.direction * d)
        else:
            print("The line is parallel to the plain")
            point = None
        return point


class Ray(Vector):
    """
    A Class representing light rays
    """

    def __init__(self, origin: Scalar, target: Scalar, wavelength: float, hole_diameter: float, intensity: int):
        super(Ray, self).__init__(p1=origin, p2=target)

        self.wavelength = wavelength
        self.hole_diameter = hole_diameter
        self.phase = None
        self.intensity = intensity


class Matrix:
    def __init__(self, arr: np.ndarray):
        self.rows, self.columns = np.shape(arr)
        for indx in np.arange(self.rows):
            for indy in np.arange(self.columns):
                setattr(self, 'm' + str(indx) + str(indy), arr[indx, indy])


class CoordSystem:
    def __init__(self, x_axis: Vector, y_axis: Vector, z_axis: Vector):
        if x_axis.start == y_axis.start and x_axis.start == y_axis.start:
            self.origin = x_axis.start
            self.xaxis = x_axis.direction
            self.yaxis = y_axis.direction
            self.zaxis = z_axis.direction
            self.xaxis_h = self.homogen(self.xaxis)
        else:
            pass

    def transform(self, translation: Scalar, rotation: Scalar, scaling: Scalar, ):
        tM = np.zeros((4, 4))
        tM[0, 3] = translation.x
        tM[1, 3] = translation.y
        tM[2, 3] = translation.z

    def homogen(self, pos: Scalar):
        pos.w = 1
        return pos

    def translate(self, dx, dy, dz):
        ...

    def scale(self):
        ...

    def sheare(self):
        ...

    def mirror(self, mirrorplane: str):
        if mirrorplane == "xy":
            pass
        elif mirrorplane == "xz":
            pass
        elif mirrorplane == "yz":
            pass
        else:
            print("No valid mirror plane was choosen: Valid mirror planes are: xy, xz, yz")
        return -1


def rotate(points, pitch, roll, yaw):
    """
    This function rotates a scalar around a given axis.
    """
    cosa = np.cos(yaw)
    sina = np.sin(yaw)

    cosb = np.cos(pitch)
    sinb = np.sin(pitch)

    cosc = np.cos(roll)
    sinc = np.sin(roll)

    Axx = cosa * cosb
    Axy = cosa * sinb * sinc - sina * cosc
    Axz = cosa * sinb * cosc + sina * sinc

    Ayx = sina * cosb
    Ayy = sina * sinb * sinc + cosa * cosc
    Ayz = sina * sinb * cosc - cosa * sinc

    Azx = -sinb
    Azy = cosb * sinc
    Azz = cosb * cosc

    for i, point in enumerate(points):
        px = point[0]
        py = point[1]
        pz = point[2]

        points[i, 0] = Axx * px + Axy * py + Axz * pz
        points[i, 1] = Ayx * px + Ayy * py + Ayz * py
        points[i, 2] = Azx * px + Azy * py + Azz * pz

    return points


def isRotationMatrix(R):
    """Check if the given matrix is a rotation matrix.

    Args:
        R (numpy.ndarray): Numpy ndarray to check of it is a rotation matrix

    Returns:
        bool: true - if the given matrix is a rotation matrix
              false - if the given matrix is not a rotation matrix 
    """
    Rt = np.transpose(R)
    shouldBeIdentity = np.dot(Rt, R)
    I = np.identity(3, dtype=R.dtype)
    n = np.linalg.norm(I - shouldBeIdentity)
    return n < 1e-6


def rotationMatrixToEulerAngles_(R):
    """Obsolete...

    Args:
        R (_type_): _description_

    Returns:
        _type_: _description_
    """
    # assert(isRotationMatrix(R))

    sy = np.sqrt(R[0, 0] * R[0, 0] + R[1, 0] * R[1, 0])

    singular = sy < 1e-6

    if not singular:
        alpha = np.arctan2(R[2, 1], R[2, 2])
        beta = np.arctan2(R[2, 1], R[2, 2])
        theta = np.arctan2(R[2, 1], R[2, 2])
    else:
        alpha = np.arctan2(-R[1, 2], R[1, 1])
        beta = np.arctan2(-R[2, 0], sy)
        theta = 0

    return alpha, beta, theta


def rotationMatrixToEulerAngles(R):
    alpha = np.arctan2(R[2, 1], R[2, 2])
    beta = np.arctan2(-R[2, 0], np.sqrt(R[2, 1] ** 2 + R[2, 2] ** 2))
    theta = np.arctan2(R[1, 0], R[0, 0])

    return alpha, beta, theta


def getRotation(R):
    yaw = np.arctan2(-R[2, 0], R[0, 0])
    roll = np.arcsin(R[1, 0])
    pitch = np.arctan2(-R[1, 2], R[1, 1])
    return yaw, pitch, roll


def map_value(value: float, in_min: float, in_max: float, out_min: float, out_max: float) -> float:
    """
    Maps a value from one range to another
    Returns
    -------

    """
    return (value - in_min) * (out_max - out_min) / (in_max - in_min) + out_min


def rad_to_deg(val: float) -> float:
    return val * 180 / math.pi


def deg_to_rad(val: float) -> float:
    return val * math.pi / 180


def remove_outliers_z_score(data: np.array, m=2.) -> [np.array, np.array, np.array]:
    """
    Removing outliers from a numpy array using the modified Z-score.

    @param data: The numpy array with the data series
    @param m:

    https://stackoverflow.com/questions/11686720/is-there-a-numpy-builtin-to-reject-outliers-from-a-list
    https://www.itl.nist.gov/div898/handbook/eda/section3/eda35h.htm
    """
    # check if the basic math operations work on the array
    try:
        # using the median is more robust than the mean
        median = np.median(data)

    except TypeError:
        return None, None, None

    # median absolute deviation
    deviation = np.abs(data - median)
    # scaled the distances by their (again) median value so that m is on a reasonable relative scale
    m_deviation = np.median(deviation)

    s = deviation / m_deviation if m_deviation else np.zeros(len(deviation))

    not_outlier_idx = s < m
    outlier_idx = s > m

    no_outliers = data[not_outlier_idx]
    print('Removed %s outliers from total %s data points in the array.' % (np.sum(~not_outlier_idx), len(data)))

    return no_outliers, not_outlier_idx, outlier_idx


def remove_outliers_std(data: np.array, sigma=2, remove_greater=True, remove_lesser=True, use_median=False) \
        -> [np.array, np.array, np.array]:
    """
    Removing outliers from a numpy array using the mean/median value and standard deviation.
     Optional, the upper or lower boundaries can be ignored.

    @param use_median: median instead of mean
    @param remove_lesser: if False, ignores values that are lesser than the outlier threshold
    @param remove_greater: if False, ignores values that are greater than the outlier threshold
    @param data: The numpy array with the data series
    @param sigma: multiple of std

    https://stackoverflow.com/questions/11686720/is-there-a-numpy-builtin-to-reject-outliers-from-a-list
    https://www.itl.nist.gov/div898/handbook/eda/section3/eda35h.htm
    """
    # check if the basic math operations work on the array
    try:
        # using the median is more robust than the mean
        if use_median:
            if np.isnan(data.astype(float)).any():
                mean = np.nanmedian(data)
            else:
                mean = np.median(data)
        else:
            if np.isnan(data.astype(float)).any():
                mean = np.nanmean(data)
            else:
                mean = np.mean(data)

        if np.isnan(data.astype(float)).any():
            std = np.nanstd(data)
        else:
            std = np.std(data)

    except TypeError:
        return None, None, None

    # initialize the arrays: assume we start with no outliers
    not_outlier_idx = np.ones(len(data), dtype=bool)
    outlier_idx = np.zeros(len(data), dtype=bool)
    no_outliers = []

    # go through all the elements and check whether they are out- or inside the boundaries
    for n, element in enumerate(data):
        # outside the boundaries
        if ((element >= mean + std * sigma and remove_greater) or
                (element <= mean - std * sigma and remove_lesser)):
            outlier_idx[n] = True
            not_outlier_idx[n] = False

        # inside the boundaries
        else:
            no_outliers.append(element)

    no_outliers = np.asarray(no_outliers)
    print('Removed %s outliers from total %s data points in the array.' % (np.sum(~not_outlier_idx), len(data)))

    return no_outliers, not_outlier_idx, outlier_idx


def averaged_measurement_values(data_set: np.ndarray, average_identifier_idx: int) -> (np.ndarray | None):
    """
    Groups the measured or machine values in a dataframe object according to their pos_idx value (measuring position) and calculates
    their mean value. Usually every position the machine travels is measured n-times. The resulting dataframe object then contains
    the mean values and the corresponding pos_idx value. If this dataframe object is later compared to the planned path,
    a missing measuring position will be identified.
    :return:
    """
    # filter all non-numeric columns and fill with nan
    for n in range(data_set.shape[1]):
        if not isinstance(data_set[:, n][0], float) and not isinstance(data_set[:, n][0], int):
            data_set[:, n] = np.nan

    # final array with all averaged sub arrays
    averaged_dataset = []
    # stores the measurements at the same position. This is going to be averaged
    data_set_tmp = []

    # first pos index
    pos_idx = data_set[0][average_identifier_idx]

    # loop over all measurement values and take the mean value for them with the same pos_idx
    for n in range(len(data_set)):
        # same pos_idx
        if data_set[n][average_identifier_idx] == pos_idx:
            data_set_tmp.append(data_set[n])

        # new pos_idx
        else:
            # append all the mean values to a new array
            averaged_dataset.append(np.asarray(data_set_tmp).mean(axis=0))

            # reset the row for averaging
            data_set_tmp = []
            # get next pos index
            pos_idx = data_set[n][average_identifier_idx]

            # append the current row too
            data_set_tmp.append(data_set[n])

    # append last mean value as well
    averaged_dataset.append(np.asarray(data_set_tmp).mean(axis=0))

    try:
        averaged_dataset = np.asarray(averaged_dataset)

    except ValueError:
        print('apply data set after deleting a column before calculating mean')
        return None

    return np.asarray(averaged_dataset)


def sort_measurement_values(data_set: pd.DataFrame, planned_path: pd.DataFrame):
    """
    Sorts the machine / measurement data set by the given planned data set. Sorting means, that
    the algorithm looks up the planned measurement positions (given by pos_idx) and compares
    them to the data set positions. If in the data_set is a pos_idx missing, nan is inserted.
    This makes sure, that the position is not just skipped, but indicated as "not measured".
    Also, both machine and measurement data sets will have the same length.
    :param data_set: averaged data_set of either machine or measurement values
    :param planned_path: averaged planned path data set
    :return:
    """
    # convert dataframes to lists for easier and faster handling
    data_set_as_list = data_set.values.tolist()
    planned_path_as_list = planned_path.values.tolist()

    # create a nan dataframe row based on the data set columns
    insert_nan = pd.DataFrame(np.nan, index=[0], columns=data_set.columns)

    for n in range(len(planned_path)):
        if data_set_as_list[n][data_set.columns.get_loc('pos_idx')] != \
                planned_path_as_list[n][planned_path.columns.get_loc('pos_idx')]:
            # set current pos_idx to the insert row
            insert_nan['pos_idx'] = n
            # insert the nan row into the data set
            data_set_as_list.insert(n, insert_nan.values.tolist()[0])

    # transform back to a dataframe object
    sorted_data_set = pd.DataFrame(data_set_as_list, columns=data_set.columns)
    return sorted_data_set


def threshold_image(image: np.ndarray, algo: str, thresh: float,
                    camera_bits: (np.uint8 | np.uint16) = np.uint8) -> (np.ndarray | None):
    """
    Applies a threshold algorithm (can be selected) to the image.
    """
    if camera_bits == np.uint8:
        max_value = 2 ** 8 - 1

    elif camera_bits == np.uint16:
        max_value = 2 ** 16 - 1

    else:
        max_value = 2 ** 8 - 1

    if algo == "Fixed Value":
        t = (image.max() * thresh).astype(camera_bits)
        th_img = cv2.threshold(image, t, max_value, cv2.THRESH_BINARY)[1]

    elif algo == "Mean Value":
        t = (image.mean() * thresh).astype(camera_bits)
        th_img = cv2.threshold(image, t, max_value, cv2.THRESH_BINARY)[1]

    elif algo == "Yen's Algorithm":
        t = filters.threshold_yen(image)
        th_img = cv2.threshold(image, t, max_value, cv2.THRESH_BINARY)[1]

    elif algo == "Li's Algorithm":
        t = filters.threshold_li(image)
        th_img = cv2.threshold(image, t, max_value, cv2.THRESH_BINARY)[1]

    else:
        print("No valid Threshold Algorithm chosen!")
        return None

    return th_img

def calc_r(x_c, y_c, data_set):
    """ calculate the distance of each 2D points from the center (x_c, y_c) """
    return np.sqrt((data_set[:, 0]-x_c)**2 + (data_set[:, 1]-y_c)**2)

def f_2(center_estimate, data_set):
    """ calculate the algebraic distance between the data points and the mean circle centered at c=(xc, yc) """
    Ri = calc_r(*center_estimate, data_set)
    return Ri - Ri.mean()

def least_squares_circle(data_set: np.ndarray, center_estimate_x: float, center_estimate_y: float):
    """
    calculates best fitting circle via method of least squares over all data points

    https://scipy-cookbook.readthedocs.io/items/Least_Squares_Circle.html

    :return: calculated center point and radius
    """
    new_center, radius = optimize.leastsq(f_2,(center_estimate_x, center_estimate_y),data_set)
    x_c , y_c = new_center

    ri_2 = calc_r(*new_center, data_set)
    r_2 = ri_2.mean()
    residu_2 = sum((ri_2 - r_2)**2)

    return x_c, y_c, r_2, residu_2