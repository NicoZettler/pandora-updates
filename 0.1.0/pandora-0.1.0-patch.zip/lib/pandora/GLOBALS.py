"""
    Created by Luis Garcia in 2020
    @ HS-AALEN, ZOT
    as PCAPS Software package
    for OnPoRob-Project
    Copyright 2020 ZOT

    DO NOT MOVE THIS FILE IN A SUB DIRECTORY!!!
"""
import pathlib
import platform
import re
import sys
import pkg_resources
import subprocess
import scipy.fft
import numpy as np
import math
from sklearn.neighbors import NearestNeighbors

from pandora.GUI.pyqtImport import *
from pandora.datatypes import Point, Workobject, Tool, Path

# ROOT_DIR points to pandora/src/pandora
ROOT_DIR = str(pathlib.Path(__file__).parent.resolve())
PLATFORM = platform.machine()
GETPOS_ARRAY_LEN = 13

perpendicular_ori = True
first_img_taken = False
full_led_mode = True
# start_of_drive = False
start_of_correction = False
use_plotly = True  # Change this to False to use matplotlib

plotly_scale_factor = 10000 / 36016847  # Estimated by trial and error using 10 hr polishing experiments
plotly_window_size = 1  # Window size for min_max_downsampling

OPEN_MSG = 'connect'
CLOSE_MSG = 'disconnect'
RESTART_MSG = 'restart'
GET_POS = 'get_POS'
REQ_GET_POS = 'req_get_pos'
REQ_GET_SET_POS = 'req_get_set_pos'
GET_POS_MAPS = 'GET_POS_MAPS'
GET_WOBJ = 'get_WOBJ'
GET_TOOL = 'get_TOOL'
GET_TIMESTAMP = 'get_timestamp'
MOVEL_POS = 'MoveL_POS_Linear'
MOVEL_QUEUE = 'MoveL_POS_queue'  # robot acknowledges that it received a position object
MOVEL_LIST = 'new_list'
MOVEL_PART = 'part'
QUEUE_EOL = 'queue_EOL'
CONFIG = 'config'
C_WOBJ = 'correct_wobj'
C_TOOL = 'correct_tool'

HIGH = 1
LOW = 0
# list of the pin numbers where the LEDs are connected to the Jetson
#     13
# 16     15
LED_GPIOS = [16, 15, 13]
SLEEP5MS = 0.005
SLEEP10MS = 0.01
SLEEP100MS = 0.1
SLEEP1000MS = 1.0

# List of CMM-OS commands without variables
CMM_ConnectApp = "ConnectApp(PCAPS_CMM)\r\n"
CMM_CloseConnection = "CF\r\n"
CMM_EOL = "\r\n"  # Command terminator
CMM_PD = "PD\r\n"  # Get current X-Y-Z position
CMM_CTP0 = "CTP0\r\n"  #
CMM_CTP1 = "CTP1\r\n"  # Use machine coordinates
CMM_CTP3 = "CTP3\r\n"  # Use machine coordinates with temperature correction

single_selection = QAbstractItemView.SelectionMode.SingleSelection
multi_selection = QAbstractItemView.SelectionMode.MultiSelection
column_selection = QAbstractItemView.SelectionBehavior.SelectColumns
row_selection = QAbstractItemView.SelectionBehavior.SelectRows
item_selection = QAbstractItemView.SelectionBehavior.SelectItems
no_selection = QAbstractItemView.SelectionMode.NoSelection


"""
Platform specific modules start
"""
cp = None
MLX_AVAILABLE = False
NUMBA_AVAILABLE = False
CUPY_AVAILABLE = False

# check if MLX is available
try:
    import mlx.core as mx
except ModuleNotFoundError:
    print('Please install MLX (only supported on Apple Silicon platforms)!')
else:
    MLX_AVAILABLE = True

# check if numba and rocket-fft is available
required = {'rocket-fft', 'numba'}
installed = {pkg.key for pkg in pkg_resources.working_set}
missing = required - installed

if missing:
    # print('Please install rocket-fft and numba!')
    print('Modules rocket-fft and numba are missing! Trying to install them now...')
    try:
        python = sys.executable
        subprocess.check_call([python, '-m', 'pip', 'install', *missing], stdout=subprocess.DEVNULL)
    except Exception as e:
        print(e)
    else:
        NUMBA_AVAILABLE = True
else:
    NUMBA_AVAILABLE = True

if NUMBA_AVAILABLE:
    import numba as nb

# check if pyculib is available
try:
    import cupy as cp
    import cupyx.scipy.fft as cufft

except ModuleNotFoundError:
    print('Please install cupy (only supported on NVIDIA platforms and requires CUDA Toolkit)!')
else:
    scipy.fft.set_global_backend(cufft)
    CUPY_AVAILABLE = True

"""
Platform specific modules end
"""

stylesheet_csv = """
            QTableWidget::item 
            {
                color: green;                    
                border-radius: 9px;
                font-style: bold;
            }

            QTableWidget::item:selected 
            {
                color: green;
                border-radius: 9px;
                font-style: bold;
                border-top: 2px solid green;
                border-left: 2px solid green;
                border-right: 2px solid green;
                border-bottom: 2px solid green;
            }
        """

stylesheet_image = """
            QTableWidget::item 
            {
                color: orange;                    
                border-radius: 9px;
                font-style: bold;
            }

            QTableWidget::item:selected 
            {
                color: orange;
                border-radius: 9px;
                font-style: bold;
                border-top: 2px solid orange;
                border-left: 2px solid orange;
                border-right: 2px solid orange;
                border-bottom: 2px solid orange;
            }
        """

stylesheet_wli = """
            QTableWidget::item 
            {
                color: blue;                    
                border-radius: 9px;
                font-style: bold;
            }

            QTableWidget::item:selected 
            {
                color: blue;
                border-radius: 9px;
                font-style: bold;
                border-top: 2px solid blue;
                border-left: 2px solid blue;
                border-right: 2px solid blue;
                border-bottom: 2px solid blue;
            }
        """

stylesheet_others = """
            QTableWidget::item 
            {
                border-radius: 9px;
                font-style: bold;
            }

            QTableWidget::item:selected 
            {
                color: black;
                background-color: white;
                border-radius: 9px;
                font-style: bold;
                border-top: 2px solid black;
                border-left: 2px solid black;
                border-right: 2px solid black;
                border-bottom: 2px solid black;
            }
        """


# List of CMM-OS commands with variables
def CMM_MW(point):  # Move absolute and wait until the CMM reaches the position afterwards the
    return "MFX%.8fY%.8fZ%.8f\r\n" % (point.pose.pos.x, point.pose.pos.y, point.pose.pos.z)


# def init():
#     global start_of_drive
#     start_of_drive = False


def timeit(func):
    import time
    """
    Decorator for measuring function's running time.
    """

    def measure_time(*args, **kw):
        start_time = time.time()
        result = func(*args, **kw)
        print("Processing time of %s(): %.2f seconds."
              % (func.__qualname__, time.time() - start_time))
        return result

    return measure_time


def atoi(text):
    return int(text) if text.isdigit() else text


def natural_sorting(text):
    """Natural sorting algorithm.

    alist.sort(key=natural_keys) sorts in human order
    http://nedbatchelder.com/blog/200712/human_sorting.html
    (See Toothy's implementation in the comments)
    """
    return [atoi(c) for c in re.split(r'(\d+)', text)]


def pose_msg_to_points(pos_arr: [str]) -> Point:
    current_pos = Point()

    if REQ_GET_POS in pos_arr:
        idx_keyword = pos_arr.index(REQ_GET_POS)

    elif GET_POS in pos_arr:
        idx_keyword = pos_arr.index(GET_POS)

    elif REQ_GET_SET_POS in pos_arr:
        idx_keyword = pos_arr.index(REQ_GET_SET_POS)

    else:
        print('Wrong command: ' + pos_arr)
        return None

    try:
        if len(pos_arr) == GETPOS_ARRAY_LEN:
            current_pos.pose.pos.x = round(float(pos_arr[idx_keyword + 1]), 9)
            current_pos.pose.pos.y = round(float(pos_arr[idx_keyword + 2]), 9)
            current_pos.pose.pos.z = round(float(pos_arr[idx_keyword + 3]), 9)

            current_pos.pose.orient.q0 = round(float(pos_arr[idx_keyword + 4]), 9)
            current_pos.pose.orient.q1 = round(float(pos_arr[idx_keyword + 5]), 9)
            current_pos.pose.orient.q2 = round(float(pos_arr[idx_keyword + 6]), 9)
            current_pos.pose.orient.q3 = round(float(pos_arr[idx_keyword + 7]), 9)

            current_pos.timestamp = round(float(pos_arr[idx_keyword + 12]), 9)
            current_pos.lin_speed = 0

        else:
            return None

    except ValueError:
        return None

    else:
        return current_pos


def tool_msg_to_tool(msg: str) -> Tool:
    current_tool = Tool()
    tool_array = msg.split(';')

    if GET_TOOL in tool_array:
        idx_keyword = tool_array.index(GET_TOOL)

        current_tool.tframe.pos.x = round(float(tool_array[idx_keyword + 1]), 9)
        current_tool.tframe.pos.y = round(float(tool_array[idx_keyword + 2]), 9)
        current_tool.tframe.pos.z = round(float(tool_array[idx_keyword + 3]), 9)

        current_tool.tframe.orient.q0 = round(float(tool_array[idx_keyword + 4]), 9)
        current_tool.tframe.orient.q1 = round(float(tool_array[idx_keyword + 5]), 9)
        current_tool.tframe.orient.q2 = round(float(tool_array[idx_keyword + 6]), 9)
        current_tool.tframe.orient.q3 = round(float(tool_array[idx_keyword + 7]), 9)

        return current_tool

    else:
        print('Robot did not send the tool data!')
        return None


def wobj_msg_to_workobject(msg: str) -> Workobject:
    current_wobj = Workobject()
    wobj_arr = msg.split(';')

    if GET_WOBJ in wobj_arr:
        idx_keyword = wobj_arr.index(GET_WOBJ)

        current_wobj.uframe.pos.x = round(float(wobj_arr[idx_keyword + 1]), 9)
        current_wobj.uframe.pos.y = round(float(wobj_arr[idx_keyword + 2]), 9)
        current_wobj.uframe.pos.z = round(float(wobj_arr[idx_keyword + 3]), 9)
        current_wobj.uframe.orient.q0 = round(float(wobj_arr[idx_keyword + 4]), 9)
        current_wobj.uframe.orient.q1 = round(float(wobj_arr[idx_keyword + 5]), 9)
        current_wobj.uframe.orient.q2 = round(float(wobj_arr[idx_keyword + 6]), 9)
        current_wobj.uframe.orient.q3 = round(float(wobj_arr[idx_keyword + 7]), 9)

        current_wobj.oframe.pos.x = round(float(wobj_arr[idx_keyword + 8]), 9)
        current_wobj.oframe.pos.y = round(float(wobj_arr[idx_keyword + 9]), 9)
        current_wobj.oframe.pos.z = round(float(wobj_arr[idx_keyword + 10]), 9)
        current_wobj.oframe.orient.q0 = round(float(wobj_arr[idx_keyword + 11]), 9)
        current_wobj.oframe.orient.q1 = round(float(wobj_arr[idx_keyword + 12]), 9)
        current_wobj.oframe.orient.q2 = round(float(wobj_arr[idx_keyword + 13]), 9)
        current_wobj.oframe.orient.q3 = round(float(wobj_arr[idx_keyword + 14]), 9)

        return current_wobj

    else:
        print('Robot did not send the work object data!')


def degC(value=''):
    return value + '\N{DEGREE SIGN}'


def find_nearest(array: np.ndarray, value: float):
    """
    Returns the element of array that is nearest to value. Return nan if one element in array is nan.
    """
    idx = (np.abs(array - value)).argmin()
    return array[idx], idx


def find_nearest_skip_nan(array: np.ndarray, value: float):
    """
    Returns the element of array that is nearest to value. Skips nans, but increases index.
    """
    nearest = None
    idx = None

    # find first element of array, that is not nan
    for n, element in enumerate(array):
        if not np.isnan(element):
            nearest = element
            idx = n
            break

    if nearest is None:
        return None, None

    # get nearest element of array to value
    for n, element in enumerate(array):
        if np.isnan(element):
            continue

        else:
            if np.abs(element - value) < nearest:
                nearest = element
                idx = n

    if idx is None:
        return None, None

    return nearest, idx


def debugger_is_active() -> bool:
    """Return if the debugger is currently active"""
    return hasattr(sys, 'gettrace') and sys.gettrace() is not None
