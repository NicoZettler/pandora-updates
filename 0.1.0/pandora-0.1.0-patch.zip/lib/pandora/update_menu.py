# src/pandora/update_menu.py
# Optional: Manual update trigger for testing
import sys


def check_for_updates_manually():
    """Manual update check - useful for testing"""

    # Get reference to updater (set by bootstrap launcher)
    if '__pandora_updater__' in sys.modules:
        updater = sys.modules['__pandora_updater__']

        print("Checking for updates manually...")

        # Force update check regardless of timing
        manifest = updater.check_for_updates_sync()

        if manifest:
            version = manifest['version']
            current = updater.get_current_version()

            print(f"Update available: {current} -> {version}")

            # Ask user if they want to install
            response = input("Install update now? (y/n): ").strip().lower()

            if response == 'y':
                print("Installing update...")
                success = updater.install_update(manifest)

                if success:
                    print("Update installed successfully!")
                    print("Restart the application to use the new version.")
                else:
                    print("Update installation failed. Check logs.")
            else:
                print("Update postponed.")
        else:
            print("No updates available.")
    else:
        print("Updater not available (not launched via bootstrap)")


def get_current_version_info():
    """Get current version information"""
    if '__pandora_updater__' in sys.modules:
        updater = sys.modules['__pandora_updater__']
        current = updater.get_current_version()
        app_path = updater.get_app_path()

        print(f"Current version: {current or 'Unknown'}")
        print(f"Loaded from: {app_path}")

        if current:
            print("Running updated version from overlay")
        else:
            print("Running bundled version")
    else:
        print("Version info not available")


# Example integration into your main app menu
def show_update_menu():
    """Example update menu for your app"""
    while True:
        print("\n" + "=" * 40)
        print("UPDATE MENU")
        print("=" * 40)
        print("1. Check current version")
        print("2. Check for updates manually")
        print("3. Back to main menu")

        choice = input("\nYour choice: ").strip()

        if choice == "1":
            get_current_version_info()
        elif choice == "2":
            check_for_updates_manually()
        elif choice == "3":
            break
        else:
            print("Invalid choice!")