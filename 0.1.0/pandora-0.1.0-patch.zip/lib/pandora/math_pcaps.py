'''
    Created by Luis Garcia in 2020
    @ HS-AALEN, ZOT
    as PCAPS Software package
    for OnPoRob-Project
    Copyright 2020 ZOT
'''

import math
import numpy as np
from numpy import sin, cos

from pandora.datatypes import EulerAngles, Pos, Orient


class Derivation:
    def __init__(self, x=0, y=0, z=0, q0=0, q1=0, q2=0, q3=0):
        super(Derivation, self).__init__()

        self.xDer = x
        self.yDer = y
        self.zDer = z
        self.q0Der = q0
        self.q1Der = q1
        self.q2Der = q2
        self.q3Der = q3

    # TODO: in the future whe should return which error is outside the threshold and only correct that
    def derivation_in_threshold(self, threshold):
        if (abs(self.xDer) > threshold.xDer or abs(self.yDer) > threshold.yDer or abs(self.zDer) > threshold.zDer or
                abs(self.q0Der) > threshold.q0Der or abs(self.q1Der) > threshold.q1Der or abs(
                    self.q2Der) > threshold.q2Der or
                abs(self.q3Der) > threshold.q3Der):
            return False
        else:
            return True


# takes position from quaternion calculator and gets diff to robot com
def calculate_maps_derivation(maps_pos, robo_pos):
    diff = Derivation()

    diff.xDer = robo_pos.pose.pos.x - maps_pos.pose.pos.x
    diff.yDer = robo_pos.pose.pos.y - maps_pos.pose.pos.y
    diff.zDer = robo_pos.pose.pos.z - maps_pos.pose.pos.z

    # TODO: is that correct?
    # diff.q1 = robo_pos.q1 - maps_pos.q1
    # diff.q2 = robo_pos.q2 - maps_pos.q2
    # diff.q3 = robo_pos.q3 - maps_pos.q3
    # diff.q4 = robo_pos.q4 - maps_pos.q4

    return diff


def add_derivation(base, diff):
    base.xDer += diff.xDer
    base.yDer += diff.yDer
    base.zDer += diff.zDer

    return base


def sub_derivation(base, diff):
    base.xDer -= diff.xDer
    base.yDer -= diff.yDer
    base.zDer -= diff.zDer

    return base


def derivation_on_pose(tool, derivation):
    tool.tframe.pos.x += derivation.xDer
    tool.tframe.pos.y += derivation.yDer
    tool.tframe.pos.z += derivation.zDer

    # TODO: is that correct?
    # tool.tframe.orient.q0 += derivation.orient.q0
    # tool.tframe.orient.q1 += derivation.orient.q1
    # tool.tframe.orient.q2 += derivation.orient.q2
    # tool.tframe.orient.q3 += derivation.orient.q3

    return tool


class Vector3D:
    def __init__(self, x=0.0, y=0.0, z=0.0, a=0.0, b=0.0, g=0.0):
        self.x = x
        self.y = y
        self.z = z

        self.a = a
        self.b = b
        self.g = g

        self.len = self.norm()

    def is_zero_vector(self):
        return True if self.x == 0.0 and self.y == 0.0 and self.z == 0.0 else False

    def norm(self):
        # returns the length of the vector
        leng = math.sqrt(sum([self.x ** 2, self.y ** 2, self.z ** 2]))
        self.len = leng
        return leng

    def arguments(self, rad: bool = True):
        # returns the angle alpha, beta, gamma of the vector
        if self.is_zero_vector():
            print('No angle for zero vector!')
            return

        arg_rad_a = math.acos(self.x * Vector3D(1, 0, 0).x / self.norm())
        arg_rad_b = math.acos(self.y * Vector3D(0, 1, 0).y / self.norm())
        arg_rad_g = math.acos(self.z * Vector3D(0, 0, 1).z / self.norm())

        arg_deg_a = arg_rad_a * 180 / math.pi
        arg_deg_b = arg_rad_b * 180 / math.pi
        arg_deg_g = arg_rad_g * 180 / math.pi

        # check - should be 1
        # print(math.cos(arg_rad_a)**2 + math.cos(arg_rad_b)**2 + math.cos(arg_rad_g)**2)
        # in degree
        # print(arg_deg_a, arg_deg_b, arg_deg_g)
        if rad:
            return arg_rad_a, arg_rad_b, arg_rad_g
        else:
            return arg_deg_a, arg_deg_b, arg_deg_g

    def normalize(self):
        normalized = Vector3D()
        normalized.x = self.x / self.norm()
        normalized.y = self.y / self.norm()
        normalized.z = self.z / self.norm()
        return normalized

    def scalar_product(self, vec, phi: float):
        # scalar product (inner product) of self and vec vector with intersection angle phi
        return self.norm() * vec.norm() * math.cos(phi)

    def scalar_product_c(self, vec):
        # scalar product (inner product) of self and vec vector (component representation)
        return self.x * vec.x + self.y * vec.y + self.z * vec.z

    def scalar_mul(self, lam: float = 0.0):
        # multiply self vector with factor lam
        # lam > 1 vector gets longer
        # 0 < lam < 1 vector gets shorter
        # lam < 0 vector changes direction (180°)
        return Vector3D(self.x * lam, self.y * lam, self.z * lam)

    def inter_angle(self, vec, rad: bool = True):
        # intersection angle between two vectors (self, vec) which are not zero vectors
        if self.is_zero_vector() or vec.is_zero_vector():
            print('One of the vectors is a zero vector!')
            return

        phi = math.acos(self.scalar_product_c(vec) / (self.norm() * vec.norm()))

        return phi if rad else (phi * 180 / math.pi)

    def is_orthogonal(self, vec):
        # check if vec is orthogonal to self
        return True if self.inter_angle(vec) == 0 else False

    def projection(self, vec, phi: float):
        # projection of vec on self vector
        p = self.scalar_product((self.scalar_product(vec, phi) / self.norm() ** 2), phi)
        return p

    def vector_product(self, vec, phi: float):
        # vector product (cross product) of self vector and vec
        # phi: angle between self and vec
        # c_abs equals the surface area of vectors self * vec
        # c is orthogonal to self and vec
        c_abs = self.norm() * vec.norm() * math.sin(phi)
        return c_abs

    def vector_product_c(self, vec):
        # vector product (cross product) in component representation of self vector and vec
        c = Vector3D()
        c.x = self.y * vec.z - self.z * vec.y
        c.y = self.z * vec.x - self.x * vec.z
        c.z = self.x * vec.y - self.y * vec.x
        return c

    def late_product(self, b, c):
        # late product of vectors self, b and c
        return self.scalar_product_c(b.vector_product_c(c))

    def late_product_c(self, b, c):
        # late product in component representation of vectors self, b and c
        # argument of late product is the volume between the three vectors
        return self.x * (b.y * c.z - b.z * c.y) + self.y * (b.z * c.x - b.x * c.z) + self.z * (b.x * c.y - b.y * c.x)

    def is_complanar(self, b, c):
        # all three vectors are on one plane
        return True if self.late_product_c(b, c) == 0 else False


def rotation_matrix(order: str, e_angle: EulerAngles) -> np.array:
    """
    Calculates the rotation matrix by given euler angles and rotation order.
    :param order: rotation order (e.g. 'xyz')
    :param e_angle: EulerAngles object
    :return: rotation matrix in np.array() style
    """
    Rz = np.array([[cos(e_angle.yaw), -sin(e_angle.yaw), 0], [sin(e_angle.yaw), cos(e_angle.yaw), 0], [0, 0, 1]])
    Ry = np.array(
        [[cos(e_angle.pitch), 0, sin(e_angle.pitch)], [0, 1, 0], [-sin(e_angle.pitch), 0, cos(e_angle.pitch)]])
    Rx = np.array([[1, 0, 0], [0, cos(e_angle.roll), -sin(e_angle.roll)], [0, sin(e_angle.roll), cos(e_angle.roll)]])

    if order == 'zyx':
        Rzy = np.matmul(Rz, Ry)
        Rzyx = np.matmul(Rzy, Rx)
        return Rzyx

    elif order == 'yzx':
        Ryz = np.matmul(Ry, Rz)
        Ryzx = np.matmul(Ryz, Rx)
        return Ryzx

    if order == 'xyz':
        Rxy = np.matmul(Rx, Ry)
        Rxyz = np.matmul(Rxy, Rz)
        return Rxyz

    else:
        print('Unknown order!')
        return None


def rotate_pos(pos: Pos, rot_matrix) -> Pos:
    """
    Rotates a pos (x,y,z) by given rotation matrix.
    :param pos: Pos object
    :param rot_matrix: rotation matrix
    :return: (rotated) Pos object
    """
    rotated_pos = Pos()

    try:
        rotated_pos.x = rot_matrix[0][0] * pos.x + rot_matrix[0][1] * pos.y + rot_matrix[0][2] * pos.z
        rotated_pos.y = rot_matrix[1][0] * pos.x + rot_matrix[1][1] * pos.y + rot_matrix[1][2] * pos.z
        rotated_pos.z = rot_matrix[2][0] * pos.x + rot_matrix[2][1] * pos.y + rot_matrix[2][2] * pos.z

    except TypeError as e:
        # do not ignore or pass such errors!!! The robot TCP pose calculation is wrong then and to robot moves totally
        # retarded
        # raise e
        print(e)
        return None

    return rotated_pos


# @njit
def dot_product(a: np.ndarray, b: np.ndarray) -> float:
    """
    Calculate the dot product of two given arrays.

    Args:
        a (numpy.array): Array 1
        b (numpy.array): Array 2

    Returns:
        res (numpy.array): Dot product of array 1 and array 2
    """
    l1 = len(a)
    l2 = len(b)
    if l1 == l2:
        result = 0
        for i in np.arange(l1):
            result += a[i] * b[i]

        return result

    else:
        return None


